import csv

f = open('test_scores.csv')
csvfile = csv.reader(f)

def average(lst):
    l = float(len(lst))
    return sum(lst)/l

header = False

males = []
females = []

for row in csvfile:
    if not header:
        header = True
    else:
        if row[1] == 'F':
            females.append(int(row[3]))
        else:
            males.append(int(row[3]))
print 'Female:', average(females)
print 'Male:', average(males)
f.close()

